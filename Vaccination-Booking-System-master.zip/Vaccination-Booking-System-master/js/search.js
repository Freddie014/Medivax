const queryString = window.location.search;
console.log(queryString);
const urlParams = new URLSearchParams(queryString);
const ZIP = urlParams.get('ZIP');
const county = urlParams.get('county')
document.getElementById("zip").innerHTML= "Your Zip Code is:"   +ZIP ;
document.getElementById("county").innerHTML= "Your County Code is:"   +county ;
 
let map;

    function initMap() 
    {
    map = new google.maps.Map(document.getElementById("map"), 
     {
        center: { lat: -34.397, lng: 150.644 },
        zoom: 8,
     });
} 