function searchValidation() {
    var zip = document.getElementById('ZIP').value;
    var county =document.getElementById('County').value;
    if((zip || county)){
        document.getElementById('zip_code').innerHTML="";
        document.getElementById('County').innerHTML="";
        return true;
    }
        
        document.getElementById('zip_code').innerHTML="**Required";
        document.getElementById('County').innerHTML="**Required";
        return false;
   
}

    